# Connection: BAND
# Host: localhost
# Saved: 2004-05-18 23:28:00
# 
# Connection: BAND
# Host: localhost
# Saved: 2004-05-18 23:06:49
# 
# Connection: BAND
# Host: localhost
# Saved: 2004-05-18 22:57:18
# 
# Connection: BAND
# Host: localhost
# Saved: 2004-05-18 22:50:29
# 
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE=NO_AUTO_VALUE_ON_ZERO */;
SET FOREIGN_KEY_CHECKS = 0;
DROP DATABASE IF EXISTS `books`;
CREATE DATABASE `books`;
USE `books`;

DROP TABLE IF EXISTS `publisher`;
CREATE TABLE `publisher` (
  `PublisherID` int(11) NOT NULL auto_increment,
  `PublisherName` varchar(50) NOT NULL default '',
  `PublisherCity` varchar(50) NOT NULL default '',
  `PublisherContact_Email` varchar(100) NOT NULL default '',
  `PublisherWebsite` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`PublisherID`)
) TYPE=InnoDB;
INSERT INTO `publisher` (`PublisherID`,`PublisherName`,`PublisherCity`,`PublisherContact_Email`,`PublisherWebsite`) VALUES (1,'APress','Berkeley','someguy@apress.com','http://www.apress.com'),(2,'Friends Of Ed','Birmingham','aneditor@friendsofed.com','http://www.friendsofed.com'),(3,'SAMS','Indianapolis','helper@samspublishing.com','http://www.samspublishing.com'),(4,'Addison Wesley','Boston','manager@aw.com','http://www.awprofessional.com'),(5,'Manning','Greenwich','theboss@manning.com','http://www.manning.com');

DROP TABLE IF EXISTS `author`;
CREATE TABLE `author` (
  `AuthorID` int(11) NOT NULL auto_increment,
  `AuthorFirstName` varchar(50) NOT NULL default '',
  `AuthorSurname` varchar(50) NOT NULL default '',
  `AuthorSSN` varchar(11) NOT NULL default '',
  `AuthorLastContact` datetime default '0000-00-00 00:00:00',
  PRIMARY KEY  (`AuthorID`)
) TYPE=InnoDB;
INSERT INTO `author` (`AuthorID`,`AuthorFirstName`,`AuthorSurname`,`AuthorSSN`,`AuthorLastContact`) VALUES (1,'Dan','Maharry','123-55-6254','2004-02-01 00:00:00'),(2,'Damien','Foggon','123-55-7651','2004-02-12 00:00:00'),(3,'Dave','Sussman','123-55-9164','2003-12-13 00:00:00'),(4,'Jane','Randall','123-55-1743','2004-02-14 00:00:00'),(5,'Dominic','Briffa','123-55-8632','2003-04-24 00:00:00'),(6,'Megan','Rothwell','123-55-2134','2003-11-15 00:00:00'),(7,'Dan','Squier','123-55-4122','2004-09-30 00:00:00'),(8,'James','Hart','123-55-0723','2004-02-13 00:00:00');


DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `BookID` int(11) NOT NULL auto_increment,
  `BookTitle` varchar(100) NOT NULL default '',
  `BookPublisherID` int(11) NOT NULL default '1',
  `BookMainTopic` varchar(25) NOT NULL default '',
  PRIMARY KEY  (`BookID`),
  KEY `IX_BookPublisherID` (`BookPublisherID`),
  INDEX `IX_BookMainTopic` (`BookMainTopic`),
  CONSTRAINT `FK_PublisherID_BookPublisherID` FOREIGN KEY (`BookPublisherID`) REFERENCES `publisher` (`PublisherID`)
) TYPE=InnoDB;
INSERT INTO `book` (`BookID`,`BookTitle`,`BookPublisherID`,`BookMainTopic`) VALUES (1,'Starting Up C#',2,'C#'),(2,'Beginning ASP.NET',1,'ASP.NET'),(3,'Waking Up To .NET',3,'.NET Framework'),(4,'Starting Up VB.NET',2,'VB.NET'),(5,'Beginning ASP.NET Databases',1,'ASP.NET'),(6,'Journeyman Webforms',4,'ASP.NET'),(7,'Journeyman Winforms',4,'C#'),(8,'Starting Up ADO.NET With C#',2,'ADO.NET'),(9,'Jumping From VB6 To VB.NET',5,'VB.NET'),(10,'Jumping From Java To C#',5,'C#'),(11,'Dive Into Databases With ASP.NET And VB.NET',1,'VB.NET'),(12,'Professional .NET Application Design',3,'C#'),(13,'Games .NET',5,'C#'),(14,'Journeyman E-Commerce',2,'ASP.NET'),(15,'Deep Down ASP.NET',4,'ASP.NET'),(16,'Deep Down C#',4,'C#'),(17,'Deep Down VB.NET',4,'VB.NET'),(18,'System.NET Class Library Reference',2,'.NET'),(19,'MySQL in .NET',1,'.NET'),(20,'Open Source .NET',5,'.NET'),(21,'VB .NET Reflection Handbook',1,'VB.NET'),(22,'Secure Programming',3,'C#'),(23,'Crypto .NET',5,'C#'),(24,'Delve Into Intermediate Language',1,'IL'),(25,'Professional .NET Assemblies',2,'.NET');
INSERT INTO `book` (`BookID`,`BookTitle`,`BookPublisherID`,`BookMainTopic`) VALUES (26,'Beginning ASP.NET 2.0 Preview',3,'Whidbey'),(27,'C# 2.0 Programmers Reference',3,'Whidbey'),(28,'Discovering WinFS',2,'Longhorn'),(29,'Discovering Indigo',2,'Longhorn'),(30,'Discovering Avalon',2,'Longhorn');


DROP TABLE IF EXISTS `whowrotewhat`;
CREATE TABLE `whowrotewhat` (
  `WWWBookID` int(11) NOT NULL default '0',
  `WWWAuthorID` int(11) NOT NULL default '0',
  PRIMARY KEY  (`WWWBookID`,`WWWAuthorID`),
  KEY `IX_WWWAuthorID` (`WWWAuthorID`),
  CONSTRAINT `FK_BookID_WWWBookID` FOREIGN KEY (`WWWBookID`) REFERENCES `book` (`BookID`),
  CONSTRAINT `FK_AuthorID_WWWAuthorID` FOREIGN KEY (`WWWAuthorID`) REFERENCES `author` (`AuthorID`)
) TYPE=InnoDB;
INSERT INTO `whowrotewhat` (`WWWBookID`,`WWWAuthorID`) VALUES (1,1),(3,1),(7,1),(9,1),(17,1),(19,1),(25,1),(1,2),(10,2),(11,2),(18,2),(26,2),(2,3),(3,3),(5,3),(11,3),(15,3),(19,3),(27,3),(12,4),(19,4),(20,4),(27,4),(28,4),(4,5),(13,5),(21,5),(23,5),(29,5),(6,6),(14,6),(22,6),(27,6),(30,6),(7,7),(15,7),(23,7),(30,7),(7,8),(8,8),(16,8),(24,8);


CREATE DATABASE IF NOT EXISTS `mysql`;
USE `mysql`;

DELETE FROM user WHERE User = 'BAND';
INSERT INTO `user` (`Host`,`User`,`password`,`Select_priv`,`Insert_priv`,`Update_priv`,`Delete_priv`,`Create_priv`,`Drop_priv`,`Reload_priv`,`Shutdown_priv`,`Process_priv`,`File_priv`,`Grant_priv`,`References_priv`,`Index_priv`,`Alter_priv`,`Show_db_priv`,`Super_priv`,`Create_tmp_table_priv`,`Lock_tables_priv`,`Execute_priv`,`Repl_slave_priv`,`Repl_client_priv`,`ssl_type`,`ssl_cipher`,`x509_issuer`,`x509_subject`,`max_questions`,`max_updates`,`max_connections`) VALUES ('%','BAND','032c41e8435273a7','Y','Y','Y','Y','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','','','','',0,0,0);