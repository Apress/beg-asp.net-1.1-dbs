USE CASEMASTER

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ElementAttribute_Attribute]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblElementAttribute] DROP CONSTRAINT FK_ElementAttribute_Attribute
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_DoesBrowserSupportElement_Browser]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblDoesBrowserSupportElement] DROP CONSTRAINT FK_DoesBrowserSupportElement_Browser
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_DoesBrowserSupportElementAttribute_Browser]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblDoesBrowserSupportElementAttribute] DROP CONSTRAINT FK_DoesBrowserSupportElementAttribute_Browser
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_DoesBrowserSupportElementEvent_Browser]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblDoesBrowserSupportElementEvent] DROP CONSTRAINT FK_DoesBrowserSupportElementEvent_Browser
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Image_Browser]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblImage] DROP CONSTRAINT FK_Image_Browser
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_DoesBrowserSupportElement_Element]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblDoesBrowserSupportElement] DROP CONSTRAINT FK_DoesBrowserSupportElement_Element
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_DoesStandardHaveElement_Element]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblDoesStandardHaveElement] DROP CONSTRAINT FK_DoesStandardHaveElement_Element
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ElementAttribute_Element]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblElementAttribute] DROP CONSTRAINT FK_ElementAttribute_Element
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ElementEvent_Element]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblElementEvent] DROP CONSTRAINT FK_ElementEvent_Element
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_DoesBrowserSupportElementAttribute_ElementAttribute]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblDoesBrowserSupportElementAttribute] DROP CONSTRAINT FK_DoesBrowserSupportElementAttribute_ElementAttribute
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_DoesStandardHaveElementAttribute_ElementAttribute]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblDoesStandardHaveElementAttribute] DROP CONSTRAINT FK_DoesStandardHaveElementAttribute_ElementAttribute
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_DoesBrowserSupportElementEvent_ElementEvent]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblDoesBrowserSupportElementEvent] DROP CONSTRAINT FK_DoesBrowserSupportElementEvent_ElementEvent
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_DoesStandardHaveElementEvent_ElementEvent]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblDoesStandardHaveElementEvent] DROP CONSTRAINT FK_DoesStandardHaveElementEvent_ElementEvent
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ElementEvent_Event]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblElementEvent] DROP CONSTRAINT FK_ElementEvent_Event
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_DoesStandardHaveElement_Standard]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblDoesStandardHaveElement] DROP CONSTRAINT FK_DoesStandardHaveElement_Standard
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_DoesStandardHaveElementAttribute_Standard]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblDoesStandardHaveElementAttribute] DROP CONSTRAINT FK_DoesStandardHaveElementAttribute_Standard
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_DoesStandardHaveElementEvent_Standard]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblDoesStandardHaveElementEvent] DROP CONSTRAINT FK_DoesStandardHaveElementEvent_Standard
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Image_Standard]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[tblImage] DROP CONSTRAINT FK_Image_Standard
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetBrowserImage]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[GetBrowserImage]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetStandardImage]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[GetStandardImage]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpDeleteAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpDeleteAttribute]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpDeleteBrowser]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpDeleteBrowser]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpDeleteElement]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpDeleteElement]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpDeleteEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpDeleteEvent]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpDeleteStandard]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpDeleteStandard]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpGetAllAttributes]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpGetAllAttributes]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpGetAllBrowsers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpGetAllBrowsers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpGetAllElements]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpGetAllElements]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpGetAllEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpGetAllEvents]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpGetAllStandards]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpGetAllStandards]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpGetDetailsForElementAttributeInBrowsers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpGetDetailsForElementAttributeInBrowsers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpGetDetailsForElementAttributeInStandards]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpGetDetailsForElementAttributeInStandards]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpGetDetailsForElementEventInBrowsers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpGetDetailsForElementEventInBrowsers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpGetDetailsForElementEventInStandards]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpGetDetailsForElementEventInStandards]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpGetElementAttributes]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpGetElementAttributes]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpGetElementEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpGetElementEvents]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpLoadAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpLoadAttribute]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpLoadBrowser]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpLoadBrowser]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpLoadElement]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpLoadElement]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpLoadElementAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpLoadElementAttribute]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpLoadElementEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpLoadElementEvent]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpLoadElementInBrowser]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpLoadElementInBrowser]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpLoadElementInStandard]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpLoadElementInStandard]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpLoadEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpLoadEvent]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpLoadStandard]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpLoadStandard]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpSaveAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpSaveAttribute]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpSaveBrowser]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpSaveBrowser]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpSaveElement]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpSaveElement]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpSaveElementAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpSaveElementAttribute]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpSaveElementEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpSaveElementEvent]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpSaveElementInBrowser]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpSaveElementInBrowser]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpSaveElementInStandard]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpSaveElementInStandard]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpSaveEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpSaveEvent]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpSaveStandard]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpSaveStandard]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[stpSecurityLogin]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[stpSecurityLogin]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblAttribute]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblAttribute]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblBrowser]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblBrowser]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblDoesBrowserSupportElement]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblDoesBrowserSupportElement]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblDoesBrowserSupportElementAttribute]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblDoesBrowserSupportElementAttribute]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblDoesBrowserSupportElementEvent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblDoesBrowserSupportElementEvent]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblDoesStandardHaveElement]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblDoesStandardHaveElement]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblDoesStandardHaveElementAttribute]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblDoesStandardHaveElementAttribute]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblDoesStandardHaveElementEvent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblDoesStandardHaveElementEvent]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblElement]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblElement]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblElementAttribute]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblElementAttribute]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblElementEvent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblElementEvent]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblEvent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblEvent]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblImage]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblImage]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblStandard]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblStandard]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblUser]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblUser]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE FUNCTION dbo.GetBrowserImage (@browser uniqueidentifier)
RETURNS nvarchar(64)
AS BEGIN
DECLARE @image AS nvarchar(64)
SET @image = (SELECT ImageUrl FROM tblImage WHERE BrowserID = @browser)
RETURN (@image)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE FUNCTION dbo.GetStandardImage (@standard uniqueidentifier, @deprecated bit)
RETURNS nvarchar(64)
AS BEGIN
DECLARE @image AS nvarchar(64)
SET @image = (SELECT ImageUrl FROM tblImage WHERE StandardID = @standard AND Deprecated = @deprecated)
RETURN (@image)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TABLE [dbo].[tblAttribute] (
	[AttributeID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[AttributeName] [nvarchar] (32) COLLATE Latin1_General_CI_AS NOT NULL ,
	[AttributeDescription] [nvarchar] (256) COLLATE Latin1_General_CI_AS NOT NULL ,
	[AttributeValueRange] [nvarchar] (64) COLLATE Latin1_General_CI_AS NULL ,
	[AttributeCSSAlternative] [nvarchar] (128) COLLATE Latin1_General_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblBrowser] (
	[BrowserID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[BrowserName] [nvarchar] (32) COLLATE Latin1_General_CI_AS NOT NULL ,
	[BrowserDescription] [nvarchar] (256) COLLATE Latin1_General_CI_AS NOT NULL ,
	[BrowserURL] [nvarchar] (128) COLLATE Latin1_General_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblDoesBrowserSupportElement] (
	[ElementID] [uniqueidentifier] NOT NULL ,
	[BrowserID] [uniqueidentifier] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblDoesBrowserSupportElementAttribute] (
	[ElementAttributeID] [uniqueidentifier] NOT NULL ,
	[BrowserID] [uniqueidentifier] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblDoesBrowserSupportElementEvent] (
	[ElementEventID] [uniqueidentifier] NOT NULL ,
	[BrowserID] [uniqueidentifier] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblDoesStandardHaveElement] (
	[ElementID] [uniqueidentifier] NOT NULL ,
	[StandardID] [uniqueidentifier] NOT NULL ,
	[Deprecated] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblDoesStandardHaveElementAttribute] (
	[ElementAttributeID] [uniqueidentifier] NOT NULL ,
	[StandardID] [uniqueidentifier] NOT NULL ,
	[Deprecated] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblDoesStandardHaveElementEvent] (
	[ElementEventID] [uniqueidentifier] NOT NULL ,
	[StandardID] [uniqueidentifier] NOT NULL ,
	[Deprecated] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblElement] (
	[ElementID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[ElementName] [nvarchar] (32) COLLATE Latin1_General_CI_AS NOT NULL ,
	[ElementDescription] [nvarchar] (256) COLLATE Latin1_General_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblElementAttribute] (
	[ElementAttributeID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[ElementID] [uniqueidentifier] NOT NULL ,
	[AttributeID] [uniqueidentifier] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblElementEvent] (
	[ElementEventID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[ElementID] [uniqueidentifier] NOT NULL ,
	[EventID] [uniqueidentifier] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblEvent] (
	[EventID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[EventName] [nvarchar] (32) COLLATE Latin1_General_CI_AS NOT NULL ,
	[EventDescription] [nvarchar] (256) COLLATE Latin1_General_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblImage] (
	[ImageID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[StandardID] [uniqueidentifier] NULL ,
	[BrowserID] [uniqueidentifier] NULL ,
	[Deprecated] [bit] NULL ,
	[ImageUrl] [nvarchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblStandard] (
	[StandardID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[StandardName] [nvarchar] (32) COLLATE Latin1_General_CI_AS NOT NULL ,
	[StandardDescription] [nvarchar] (256) COLLATE Latin1_General_CI_AS NOT NULL ,
	[StandardURL] [nvarchar] (128) COLLATE Latin1_General_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblUser] (
	[UserID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[Username] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Password] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpDeleteAttribute
	@attribute uniqueidentifier
AS
-- transaction as we don't want to delete half
BEGIN TRANSACTION
-- delete from BROWSER link details
DELETE FROM tblDoesBrowserSupportElementAttribute
WHERE ElementAttributeID IN (SELECT ElementAttributeID FROM tblElementAttribute WHERE AttributeID = @attribute)
-- delete from STANDARD link details
DELETE FROM tblDoesStandardHaveElementAttribute
WHERE ElementAttributeID IN (SELECT ElementAttributeID FROM tblElementAttribute WHERE AttributeID = @attribute)
-- delete the ATTRIBUTE -> ELEMENT link
DELETE FROM tblElementAttribute WHERE AttributeID = @attribute
-- now finally delete the ATTRIBUTE
DELETE FROM tblAttribute WHERE AttributeID = @attribute
-- now commit this to the database
COMMIT TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpDeleteBrowser
	@browser uniqueidentifier
AS
-- transaction as we don't want to delete half
BEGIN TRANSACTION
-- delete from ATTRIBTE link details
DELETE FROM tblDoesBrowserSupportElementAttribute WHERE BrowserID = @browser
-- delete from EVENT link details
DELETE FROM tblDoesBrowserSupportElementEvent WHERE BrowserID = @browser
-- delete from ELEMENT link details
DELETE FROM tblDoesBrowserSupportElement WHERE BrowserID = @browser
-- now finally delete the STANDARD
DELETE FROM tblBrowser WHERE BrowserID = @browser
-- now commit this to the database
COMMIT TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpDeleteElement
	@element uniqueidentifier
AS
-- transaction as we don't want to delete half
BEGIN TRANSACTION
-- delete all the ATTRIBUTE linkage stuff
DELETE FROM tblDoesStandardHaveElementAttribute WHERE ElementAttributeID IN (SELECT ElementAttributeID FROM tblElementAttribute WHERE ElementID = @element)
DELETE FROM tblDoesBrowserSupportElementAttribute WHERE ElementAttributeID IN (SELECT ElementAttributeID FROM tblElementAttribute WHERE ElementID = @element)
DELETE FROM tblElementAttribute WHERE ElementID = @element
-- delete all the EVENT linkage stuff
DELETE FROM tblDoesStandardHaveElementEvent WHERE ElementEventID  IN (SELECT ElementEventID FROM tblElementEvent WHERE ElementID = @element)
DELETE FROM tblDoesBrowserSupportElementEvent WHERE ElementEventID IN (SELECT ElementEventID FROM tblElementEvent WHERE ElementID = @element)
DELETE FROM tblElementEvent WHERE ElementID = @element
-- delete all the ELEMENT linkage stuff
DELETE FROM tblDoesStandardHaveElement WHERE ElementID = @element
DELETE FROM tblDoesBrowserSupportElement WHERE ElementID = @element
-- now finally delete the ELEMENT
DELETE FROM tblElement WHERE ElementID = @element
-- now commit this to the database
COMMIT TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpDeleteEvent
	@event uniqueidentifier
AS
-- transaction as we don't want to delete half
BEGIN TRANSACTION
-- delete from BROWSER link details
DELETE FROM tblDoesBrowserSupportElementEvent
WHERE ElementEventID IN (SELECT ElementEventID FROM tblElementEvent WHERE EventID = @event)
-- delete from STANDARD link details
DELETE FROM tblDoesStandardHaveElementEvent
WHERE ElementEventID IN (SELECT ElementEventID FROM tblElementEvent WHERE EventID = @event)
-- delete the EVENT -> ELEMENT link
DELETE FROM tblElementEvent WHERE EventID = @event
-- now finally delete the EVENT
DELETE FROM tblEvent WHERE EventID = @event
-- now commit this to the database
COMMIT TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpDeleteStandard
	@standard uniqueidentifier
AS
-- transaction as we don't want to delete half
BEGIN TRANSACTION
-- delete from ATTRIBTE link details
DELETE FROM tblDoesStandardHaveElementAttribute WHERE StandardID = @standard
-- delete from EVENT link details
DELETE FROM tblDoesStandardHaveElementEvent WHERE StandardID = @standard
-- delete from ELEMENT link details
DELETE FROM tblDoesStandardHaveElement WHERE StandardID = @standard
-- now finally delete the STANDARD
DELETE FROM tblStandard WHERE StandardID = @standard
-- now commit this to the database
COMMIT TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpGetAllAttributes
AS
-- list the names and IDs of them all
SELECT AttributeID, AttributeName FROM tblAttribute ORDER BY AttributeName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpGetAllBrowsers
AS
-- list the names and IDs of them all
SELECT BrowserID, BrowserName FROM tblBrowser ORDER BY BrowserName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpGetAllElements
AS
-- list the names and IDs of them all
SELECT ElementID, ElementName FROM tblElement ORDER BY ElementName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpGetAllEvents
AS
-- list the names and IDs of them all
SELECT EventID, EventName FROM tblEvent ORDER BY EventName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpGetAllStandards
AS
-- list the names and IDs of them all
SELECT StandardID, StandardName FROM tblStandard ORDER BY StandardName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpGetDetailsForElementAttributeInBrowsers
	@elementattribute uniqueidentifier
AS
-- simply get from the Element table
SELECT dbo.GetBrowserImage(tblDoesBrowserSupportElementAttribute.BrowserID) AS ImageUrl
FROM tblBrowser
	INNER JOIN tblDoesBrowserSupportElementAttribute ON tblBrowser.BrowserID = tblDoesBrowserSupportElementAttribute.BrowserID
WHERE tblDoesBrowserSupportElementAttribute.ElementAttributeID = @elementattribute
ORDER BY tblBrowser.BrowserName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpGetDetailsForElementAttributeInStandards
	@elementattribute uniqueidentifier
AS
-- simply get from the Element table
SELECT dbo.GetStandardImage(tblDoesStandardHaveElementAttribute.StandardID, tblDoesStandardHaveElementAttribute.Deprecated) AS ImageUrl
FROM tblStandard
	INNER JOIN tblDoesStandardHaveElementAttribute ON tblStandard.StandardID = tblDoesStandardHaveElementAttribute.StandardID
WHERE tblDoesStandardHaveElementAttribute.ElementAttributeID = @elementattribute
ORDER BY tblStandard.StandardName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpGetDetailsForElementEventInBrowsers
	@elementevent uniqueidentifier
AS
-- simply get from the Element table
SELECT tblBrowser.BrowserName, tblBrowser.BrowserDescription
FROM tblBrowser
	INNER JOIN tblDoesBrowserSupportElementEvent ON tblBrowser.BrowserID = tblDoesBrowserSupportElementEvent.BrowserID
WHERE tblDoesBrowserSupportElementEvent.ElementEventID = @elementevent

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpGetDetailsForElementEventInStandards
	@elementevent uniqueidentifier
AS
-- simply get from the Element table
SELECT tblStandard.StandardName, tblStandard.StandardDescription,  tblDoesStandardHaveElementEvent.Deprecated
FROM tblStandard
	INNER JOIN tblDoesStandardHaveElementEvent ON tblStandard.StandardID = tblDoesStandardHaveElementEvent.StandardID
WHERE tblDoesStandardHaveElementEvent.ElementEventID = @elementevent

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpGetElementAttributes
	@element uniqueidentifier
AS
-- simply get from the Attribute table if an entry for the element in ElementAttribute
SELECT tblElementAttribute.ElementAttributeID, tblAttribute.AttributeName, tblAttribute.AttributeDescription
FROM tblAttribute
	INNER JOIN tblElementAttribute ON tblAttribute.AttributeID = tblElementAttribute.AttributeID
WHERE tblElementAttribute.ElementID = @element
ORDER BY tblAttribute.AttributeName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpGetElementEvents
	@element uniqueidentifier
AS
-- simply get from the Event table if an entry for the element in ElementEvent
SELECT tblElementEvent.ElementEventID, tblEvent.EventName, tblEvent.EventDescription
FROM tblEvent
	INNER JOIN tblElementEvent ON tblEvent.EventID = tblElementEvent.EventID
WHERE tblElementEvent.ElementID = @element
ORDER BY tblEvent.EventName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpLoadAttribute
	@attribute uniqueidentifier
AS
-- get the name and description
SELECT AttributeName, AttributeDescription FROM tblAttribute WHERE AttributeID = @attribute

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpLoadBrowser
	@browser uniqueidentifier
AS
-- get the name, description and URL
SELECT tblBrowser.BrowserName, tblBrowser.BrowserDescription, tblBrowser.BrowserUrl, tblImage.ImageUrl
FROM tblBrowser 
	INNER JOIN tblImage ON tblBrowser.BrowserID = tblImage.BrowserID
WHERE tblBrowser.BrowserID = @browser

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpLoadElement
	@element uniqueidentifier
AS
-- get the name and description
SELECT ElementID, ElementName, ElementDescription FROM tblElement WHERE ElementID = @element

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpLoadElementAttribute
	@element uniqueidentifier
AS
-- get the name and description
SELECT ElementAttributeID, ElementID, AttributeID FROM tblElementAttribute WHERE ElementID = @element

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpLoadElementEvent
	@element uniqueidentifier
AS
-- get the name and description
SELECT ElementEventID, ElementID, EventID FROM tblElementEvent WHERE ElementID = @element

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpLoadElementInBrowser
	@element uniqueidentifier
AS
SELECT tblDoesBrowserSupportElement.ElementID, tblDoesBrowserSupportElement.BrowserID, dbo.GetBrowserImage(tblDoesBrowserSupportElement.BrowserID) AS ImageUrl
FROM tblBrowser
	INNER JOIN tblDoesBrowserSupportElement ON tblBrowser.BrowserID = tblDoesBrowserSupportElement.BrowserID
WHERE tblDoesBrowserSupportElement.ElementID = @element
ORDER BY tblBrowser.BrowserName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpLoadElementInStandard
	@element uniqueidentifier = null
AS
SELECT tblDoesStandardHaveElement.ElementID, tblDoesStandardHaveElement.StandardID, dbo.GetStandardImage(tblDoesStandardHaveElement.StandardID, tblDoesStandardHaveElement.Deprecated) AS ImageUrl
FROM tblStandard
	INNER JOIN tblDoesStandardHaveElement ON tblStandard.StandardID = tblDoesStandardHaveElement.StandardID
WHERE tblDoesStandardHaveElement.ElementID = @element
ORDER BY tblStandard.StandardName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpLoadEvent
	@event uniqueidentifier
AS
-- get the name and description
SELECT EventName, EventDescription FROM tblEvent WHERE EventID = @event

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpLoadStandard
	@standard uniqueidentifier
AS
-- get the name, description and URL
SELECT StandardName, StandardDescription, StandardUrl
FROM tblStandard
WHERE StandardID = @standard

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpSaveAttribute 
	@attribute uniqueidentifier = null,
	@name nvarchar(32),
	@description nvarchar(256)
AS
-- INSERT or UPDATE
IF (@attribute is null) BEGIN
	INSERT INTO tblAttribute (AttributeName, AttributeDescription)
		VALUES (@name, @description)
END ELSE BEGIN
	UPDATE tblAttribute SET AttributeName = @name, AttributeDescription = @description
		WHERE AttributeID = @attribute
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpSaveBrowser
	@browser uniqueidentifier = null,
	@name nvarchar(32),
	@description nvarchar(256),
	@url nvarchar(128),
	@imageurl nvarchar(64)
AS
-- INSERT or UPDATE
IF (@browser is null) BEGIN
	-- save the browser
	INSERT INTO tblBrowser (BrowserName, BrowserDescription, BrowserUrl)
		VALUES (@name, @description, @url)
	SET @browser = (SELECT BrowserID FROM tblBrowser WHERE BrowserName = @name)
	-- save the image
	INSERT INTO tblImage (BrowserID, ImageUrl)
		VALUES (@browser, @imageurl)
END ELSE BEGIN
	-- save the browser
	UPDATE tblBrowser SET BrowserName = @name, BrowserDescription = @description, BrowserUrl = @url
		WHERE BrowserID = @browser
	-- save the image
	UPDATE tblImage SET ImageUrl = @imageurl
		WHERE BrowserID = @browser
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpSaveElement
	@element uniqueidentifier,
	@name nvarchar(32),
	@description nvarchar(256)
AS
-- delete the element as we're about to replace everything
EXEC dbo.stpDeleteElement @element
-- now insert it
INSERT INTO tblElement (ElementID, ElementName, ElementDescription)
	VALUES (@element, @name, @description)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpSaveElementAttribute
	@elementattribute uniqueidentifier,
	@element uniqueidentifier,
	@attribute uniqueidentifier
AS
-- simple insert
INSERT INTO tblElementAttribute (ElementAttributeID, ElementID, AttributeID) 
	VALUES (@elementattribute, @element, @attribute)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpSaveElementEvent
	@elementevent uniqueidentifier,
	@element uniqueidentifier,
	@event uniqueidentifier
AS
-- simple insert
INSERT INTO tblElementEvent (ElementEventID, ElementID, EventID) 
	VALUES (@elementevent, @element, @event)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpSaveElementInBrowser
	@element uniqueidentifier,
	@browser uniqueidentifier
AS
-- add to the table
INSERT INTO tblDoesBrowserSupportElement (ElementID, BrowserID)
	VALUES (@element, @browser)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpSaveElementInStandard
	@element uniqueidentifier,
	@standard uniqueidentifier
AS
-- add to the table
INSERT INTO tblDoesStandardHaveElement (ElementID, StandardID)
	VALUES (@element, @standard)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpSaveEvent
	@event uniqueidentifier = null,
	@name nvarchar(32),
	@description nvarchar(256)
AS
-- INSERT or UPDATE
IF (@event is null) BEGIN
	INSERT INTO tblEvent (EventName, EventDescription)
		VALUES (@name, @description)
END ELSE BEGIN
	UPDATE tblEvent SET EventName = @name, EventDescription = @description
		WHERE EventID = @event
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpSaveStandard
	@standard uniqueidentifier = null,
	@name nvarchar(32),
	@description nvarchar(256),
	@url nvarchar(128)
AS
-- INSERT or UPDATE
IF (@standard is null) BEGIN
	INSERT INTO tblStandard (StandardName, StandardDescription, StandardUrl)
		VALUES (@name, @description, @url)
END ELSE BEGIN
	UPDATE tblStandard SET StandardName = @name, StandardDescription = @description, StandardUrl = @url
		WHERE StandardID = @standard
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpSecurityLogin
	@username nvarchar(32) = '',
	@password nvarchar(32) = ''
AS
SELECT tblUser.UserID
FROM tblUser
WHERE tblUser.Username = @username and tblUser.Password = @password

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

EXEC sp_grantdbaccess [BAND], [BAND]
GRANT EXECUTE  ON [dbo].[stpDeleteAttribute] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpDeleteBrowser] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpDeleteElement] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpDeleteEvent] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpDeleteStandard] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpGetAllAttributes] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpGetAllBrowsers] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpGetAllElements] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpGetAllEvents] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpGetAllStandards] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpGetDetailsForElementAttributeInBrowsers] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpGetDetailsForElementAttributeInStandards] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpGetDetailsForElementEventInBrowsers] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpGetDetailsForElementEventInStandards] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpGetElementAttributes] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpGetElementEvents] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpLoadAttribute] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpLoadBrowser] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpLoadElement] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpLoadElementAttribute] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpLoadElementEvent] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpLoadElementInBrowser] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpLoadElementInStandard] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpLoadEvent] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpLoadStandard] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpSaveAttribute] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpSaveBrowser] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpSaveElement] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpSaveElementAttribute] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpSaveElementEvent] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpSaveElementInBrowser] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpSaveElementInStandard] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpSaveEvent] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpSaveStandard] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpSecurityLogin] TO [BAND]