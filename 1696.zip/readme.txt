To install the code simply extract the contents of the ZIP file to C:\BAND\.  This will tie with the examples presented throughout the book.

The Case Study in Chatpers 12 and 13 is contained with the CaseStudy folder.  There are two folders in here:

CODE - contains all of the code for the complete Case Study
DATA - contains a database script that will create the database, minus any data, for the Case Study.

Happy coding!

Damien and Dan