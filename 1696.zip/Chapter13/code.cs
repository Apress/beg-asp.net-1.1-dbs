namespace notashop.band {
    using System;
    using System.Configuration;
    using System.Data;
    using System.Data.SqlClient;
    using System.Web;

    public class DataAccess : IDisposable {
		SqlCommand m_Command;			// holds the command
		SqlConnection m_Connection;		// holds the connection
		SqlTransaction m_Transaction;   // holds the transaction

        public DataAccess() : this(false)
        {
        }

        public DataAccess(bool IsTransaction)
        {
            // setup the connection object
			m_Connection = new SqlConnection();
			m_Connection.ConnectionString = ConfigurationSettings.AppSettings["Database"];

            // begin the transaction (if required)
            if (IsTransaction == true)
            {
                // open the connection
                OpenConnection();

                // start the transaction
                m_Transaction = m_Connection.BeginTransaction();
            }

            // reset the state of the object
            Reset();
        }

        public void Reset(){
			// setup the command object
			m_Command = new SqlCommand();
			m_Command.Connection = m_Connection;
            // add the transaction if we need to
            if (m_Transaction != null){
                m_Command.Transaction = m_Transaction;
            }
        }

		public void Dispose()
		{
            // close the database connection
            CloseConnection();

            // don't want to call the GC
            GC.SuppressFinalize(this);
		}

        private void OpenConnection()
        {
			if (m_Connection.State == ConnectionState.Closed)
			{
				m_Connection.Open();
			}
        }
        private void CloseConnection()
        {
			if (m_Connection.State == ConnectionState.Open)
			{
				m_Connection.Close();
			}
        }

        public void CommitTransaction()
        {
            m_Transaction.Commit();
        }

        public void RollbackTransaction()
        {
            m_Transaction.Rollback();
        }

		public void AddParameter(string strName, SqlDbType objType, ParameterDirection objDirection)
		{
			SqlParameter l_Param = new SqlParameter();
			l_Param.ParameterName = strName;
			l_Param.SqlDbType = objType;
			l_Param.Direction = objDirection;
			m_Command.Parameters.Add (l_Param);
		}

		public void AddParameter(string strName, SqlDbType objType, ParameterDirection objDirection, object objValue)
		{
			AddParameter(strName, objType, objDirection);
			ModifyParameter(strName, objValue);
		}

		public object GetParameter(string strName)
		{
			// does the parameter exist
			if (m_Command.Parameters.IndexOf(strName) != 0)
			{
				return(m_Command.Parameters[strName].Value);
			}
			else
			{
				return(null);
			}
		}

		public void ModifyParameter(string strName, object objValue)
		{
            // we need to play nice with GUIDs
            if (m_Command.Parameters[strName].SqlDbType == SqlDbType.UniqueIdentifier){
                // if a string then need to create a new GUID object
                if (objValue.GetType() == typeof(String)){
                    objValue = new System.Guid(objValue.ToString());
                }
            }

			 // modify the value of the parameter
    			m_Command.Parameters[strName].Value = objValue;
		}

        public void RemoveParameter(string strName)
        {
            // does the parameter exist
    		if (m_Command.Parameters.IndexOf(strName) != 0)
			{
                m_Command.Parameters.RemoveAt(m_Command.Parameters.IndexOf(strName));
            }
        }

        public SqlDataAdapter ExecuteAdapter(string strCommand)
        {
            return(ExecuteAdapter(strCommand, CommandType.StoredProcedure));
        }
        public SqlDataAdapter ExecuteAdapter(string strCommand, CommandType objType)
        {
			// set the properties correctly
			m_Command.CommandText = strCommand;
			m_Command.CommandType = objType;

            // open the database connection
            OpenConnection();

			// create the data adapater object
			SqlDataAdapter objAdapter = new SqlDataAdapter(m_Command);

			// return the adapter
			return(objAdapter);
        }

        public int ExecuteNonQuery(string strCommand)
        {
            return(ExecuteNonQuery(strCommand, CommandType.StoredProcedure));
        }
		public int ExecuteNonQuery(string strCommand, CommandType objType)
		{

			// set the properties correctly
			m_Command.CommandText = strCommand;
			m_Command.CommandType = objType;

            // open the database connection
            OpenConnection();

			// execute the query and return the correct result
			int intReturn = m_Command.ExecuteNonQuery();

            // close the connection
            CloseConnection();

			// return the result
			return(intReturn);
		}

        public SqlDataReader ExecuteReader(string strCommand)
        {
            return(ExecuteReader(strCommand, CommandType.StoredProcedure));
        }
		public SqlDataReader ExecuteReader(string strCommand, CommandType objType)
		{
			return(ExecuteReader(strCommand, objType, CommandBehavior.CloseConnection));
		}
		public SqlDataReader ExecuteReader(string strCommand, CommandType objType, CommandBehavior objBehaviour)
		{
			// set the properties correctly
			m_Command.CommandText = strCommand;
			m_Command.CommandType = objType;

            // open the database connection
            OpenConnection();

			// execute the query and return the correct result
			SqlDataReader objReader = m_Command.ExecuteReader(objBehaviour);

			// return the reader
			return(objReader);
		}

        public object ExecuteScalar(string strCommand)
        {
            return(ExecuteScalar(strCommand, CommandType.StoredProcedure));
        }
		public object ExecuteScalar(string strCommand, CommandType objType)
		{

			// set the properties correctly
			m_Command.CommandText = strCommand;
			m_Command.CommandType = objType;

			// open the database connection
			OpenConnection();

            // execute the query and return the correct result
			object objReturn = m_Command.ExecuteScalar();

            // close the connection
            CloseConnection();

            // return the result
            return (objReturn);
		}
    }

    public class Security
    {
		public static bool IsLoggedIn(bool boolRedirect)
		{
			bool l_Return = true;

			// if no user id then we're not logged in
			if (HttpContext.Current.Session["UserID"] == null)
			{
				l_Return = false;
			}

			// do we want to do the redirect
			if (boolRedirect == true && l_Return == false)
			{
				// now redirect to the login page
				HttpContext.Current.Response.Redirect(HttpContext.Current.Request.ApplicationPath.TrimEnd('/') + "/security/login.aspx");
			}

			// now return the correct vale
			return(l_Return);
		}

		public static bool Login(string strUsername, string strPassword)
		{
            // create the necessary objects
            DataAccess l_Data = new DataAccess();
            bool l_Return;

            try
            {
    			// add the parameters
                l_Data.AddParameter("@username", SqlDbType.VarChar, ParameterDirection.Input, strUsername);
                l_Data.AddParameter("@password", SqlDbType.VarChar, ParameterDirection.Input, strPassword);

                // store the user id in the session
                HttpContext.Current.Session["UserID"] = l_Data.ExecuteScalar("stpSecurityLogin");

                // return correct value of true or false
                if (HttpContext.Current.Session["UserID"] != null)
                {
                    // we've logged in so return true
                    l_Return = true;
                }
                else
                {
                    // we've not logged in so return false
                    l_Return = false;
                }
            }
            finally
            {
                // close the data connection
                l_Data.Dispose();
            }

            // return the results
            return (l_Return);
		}

		public static void Logout()
		{
			// simply abandon the session
			HttpContext.Current.Session.Abandon();
		}
    }
}
