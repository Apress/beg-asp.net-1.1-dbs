USE BANDCASE

CREATE TABLE [dbo].[tblBrowser] (
	[BrowserID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[BrowserName] [nvarchar] (32) COLLATE Latin1_General_CI_AS NOT NULL ,
	[BrowserDescription] [nvarchar] (256) COLLATE Latin1_General_CI_AS NOT NULL ,
	[BrowserURL] [nvarchar] (128) COLLATE Latin1_General_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblDoesBrowserSupportElement] (
	[ElementID] [uniqueidentifier] NOT NULL ,
	[BrowserID] [uniqueidentifier] NOT NULL 
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[tblElement] (
	[ElementID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[ElementName] [nvarchar] (32) COLLATE Latin1_General_CI_AS NOT NULL ,
	[ElementDescription] [nvarchar] (256) COLLATE Latin1_General_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblImage] (
	[ImageID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[StandardID] [uniqueidentifier] NULL ,
	[BrowserID] [uniqueidentifier] NULL ,
	[Deprecated] [bit] NULL ,
	[ImageUrl] [nvarchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblUser] (
	[UserID]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[Username] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Password] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[tblBrowser] ADD 
	CONSTRAINT [DF_BrowsersAndStandards_LevelID] DEFAULT (newid()) FOR [BrowserID],
	CONSTRAINT [PK_BrowsersAndStandards] PRIMARY KEY  CLUSTERED 
	(
		[BrowserID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblDoesBrowserSupportElement] ADD 
	CONSTRAINT [PK_DoesBrowserSupportElement] PRIMARY KEY  CLUSTERED 
	(
		[ElementID],
		[BrowserID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblElement] ADD 
	CONSTRAINT [DF_HTMLTag_TagID] DEFAULT (newid()) FOR [ElementID],
	CONSTRAINT [PK_HTMLTag] PRIMARY KEY  CLUSTERED 
	(
		[ElementID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblImage] ADD 
	CONSTRAINT [DF_Image_ImageID] DEFAULT (newid()) FOR [ImageID],
	CONSTRAINT [PK_Images] PRIMARY KEY  CLUSTERED 
	(
		[ImageID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblUser] ADD 
	CONSTRAINT [DF_tblUser_UserID] DEFAULT (newid()) FOR [UserID],
	CONSTRAINT [PK_tblUser] PRIMARY KEY  CLUSTERED 
	(
		[UserID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblDoesBrowserSupportElement] ADD 
	CONSTRAINT [FK_DoesBrowserSupportElement_Browser] FOREIGN KEY 
	(
		[BrowserID]
	) REFERENCES [dbo].[tblBrowser] (
		[BrowserID]
	),
	CONSTRAINT [FK_DoesBrowserSupportElement_Element] FOREIGN KEY 
	(
		[ElementID]
	) REFERENCES [dbo].[tblElement] (
		[ElementID]
	)
GO

ALTER TABLE [dbo].[tblImage] ADD 
	CONSTRAINT [FK_Image_Browser] FOREIGN KEY 
	(
		[BrowserID]
	) REFERENCES [dbo].[tblBrowser] (
		[BrowserID]
	)
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpGetAllElements
AS
-- list the names and IDs of them all
SELECT ElementID, ElementName FROM tblElement ORDER BY ElementName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpLoadElement
	@element uniqueidentifier
AS
-- get the name and description
SELECT ElementID, ElementName, ElementDescription FROM tblElement WHERE ElementID = @element

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpLoadElementInBrowser
	@element uniqueidentifier
AS
SELECT tblDoesBrowserSupportElement.ElementID, tblDoesBrowserSupportElement.BrowserID, ImageUrl
FROM tblBrowser
	INNER JOIN tblDoesBrowserSupportElement ON tblBrowser.BrowserID = tblDoesBrowserSupportElement.BrowserID
	INNER JOIN tblImage ON tblBrowser.BrowserID = tblImage.BrowserID
WHERE tblDoesBrowserSupportElement.ElementID = @element
ORDER BY tblBrowser.BrowserName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpSecurityLogin
	@username nvarchar(32) = '',
	@password nvarchar(32) = ''
AS
SELECT tblUser.UserID
FROM tblUser
WHERE tblUser.Username = @username and tblUser.Password = @password

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpDeleteElement
	@element uniqueidentifier
AS
-- transaction as we don't want to delete half
BEGIN TRANSACTION
-- delete all the ELEMENT linkage stuff
DELETE FROM tblDoesBrowserSupportElement WHERE ElementID = @element
-- now finally delete the ELEMENT
DELETE FROM tblElement WHERE ElementID = @element
-- now commit this to the database
COMMIT TRANSACTION

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpGetAllBrowsers
AS
-- list the names and IDs of them all
SELECT BrowserID, BrowserName FROM tblBrowser ORDER BY BrowserName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpSaveElement
	@element uniqueidentifier,
	@name nvarchar(32),
	@description nvarchar(256)
AS
-- delete the element as we're about to replace everything
EXEC dbo.stpDeleteElement @element
-- now insert it
INSERT INTO tblElement (ElementID, ElementName, ElementDescription)
	VALUES (@element, @name, @description)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.stpSaveElementInBrowser
	@element uniqueidentifier,
	@browser uniqueidentifier
AS
-- add to the table
INSERT INTO tblDoesBrowserSupportElement (ElementID, BrowserID)
	VALUES (@element, @browser)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

EXEC sp_grantdbaccess [BAND], [BAND]
GRANT EXECUTE  ON [dbo].[stpGetAllElements] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpLoadElement] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpLoadElementInBrowser] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpSecurityLogin] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpDeleteElement] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpGetAllBrowsers] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpSaveElement] TO [BAND]
GRANT EXECUTE  ON [dbo].[stpSaveElementInBrowser] TO [BAND]

DECLARE @b_ie2 uniqueidentifier
DECLARE @b_ie3 uniqueidentifier
DECLARE @b_ie4 uniqueidentifier
DECLARE @b_ie5 uniqueidentifier
DECLARE @b_nav2 uniqueidentifier
DECLARE @b_nav3 uniqueidentifier
DECLARE @b_nav4 uniqueidentifier
DECLARE @element uniqueidentifier

-- create the data that we need
INSERT tblBrowser (BrowserName, BrowserDescription, BrowserUrl) VALUES ('IE2', 'IE2', 'http://www.microsoft.com/ie');
SET @b_ie2 = (SELECT BrowserID FROM tblBrowser WHERE BrowserName = 'IE2');
INSERT tblImage (BrowserID, ImageUrl) VALUES (@b_ie2, 'images/icons/i2.gif');
INSERT tblBrowser (BrowserName, BrowserDescription, BrowserUrl) VALUES ('IE3', 'IE3', 'http://www.microsoft.com/ie');
SET @b_ie3 = (SELECT BrowserID FROM tblBrowser WHERE BrowserName = 'IE3');
INSERT tblImage (BrowserID, ImageUrl) VALUES (@b_ie3, 'images/icons/i3.gif');
INSERT tblBrowser (BrowserName, BrowserDescription, BrowserUrl) VALUES ('IE4', 'IE4', 'http://www.microsoft.com/ie');
SET @b_ie4 = (SELECT BrowserID FROM tblBrowser WHERE BrowserName = 'IE4');
INSERT tblImage (BrowserID, ImageUrl) VALUES (@b_ie4, 'images/icons/i4.gif');
INSERT tblBrowser (BrowserName, BrowserDescription, BrowserUrl) VALUES ('IE5', 'IE5', 'http://www.microsoft.com/ie');
SET @b_ie5 = (SELECT BrowserID FROM tblBrowser WHERE BrowserName = 'IE5');
INSERT tblImage (BrowserID, ImageUrl) VALUES (@b_ie5, 'images/icons/i5.gif');
INSERT tblBrowser (BrowserName, BrowserDescription, BrowserUrl) VALUES ('NAV2', 'NAV2', 'http://www.netscape.com');
SET @b_nav2 = (SELECT BrowserID FROM tblBrowser WHERE BrowserName = 'NAV2');
INSERT tblImage (BrowserID, ImageUrl) VALUES (@b_nav2, 'images/icons/n2.gif');
INSERT tblBrowser (BrowserName, BrowserDescription, BrowserUrl) VALUES ('NAV3', 'NAV3', 'http://www.netscape.com');
SET @b_nav3 = (SELECT BrowserID FROM tblBrowser WHERE BrowserName = 'NAV3');
INSERT tblImage (BrowserID, ImageUrl) VALUES (@b_nav3, 'images/icons/n3.gif');
INSERT tblBrowser (BrowserName, BrowserDescription, BrowserUrl) VALUES ('NAV4', 'NAV4', 'http://www.netscape.com');
SET @b_nav4 = (SELECT BrowserID FROM tblBrowser WHERE BrowserName = 'NAV4');
INSERT tblImage (BrowserID, ImageUrl) VALUES (@b_nav4, 'images/icons/n4.gif');

INSERT tblElement (ElementName, ElementDescription) VALUES ('A', 'Defines a hypertext link. The HREF or the NAME attribute must be specified.');
INSERT tblElement (ElementName, ElementDescription) VALUES ('ABBR', 'Indicates a sequence of characters that compose an abbreviation (e.g. "WWW").');
INSERT tblElement (ElementName, ElementDescription) VALUES ('ACRONYM', 'Indicates a word that is an acronym (e.g. "radar").');
INSERT tblElement (ElementName, ElementDescription) VALUES ('ADDRESS', 'Specifies information such as address, signature and authorship.');
INSERT tblElement (ElementName, ElementDescription) VALUES ('APPLET', 'Inserts a Java Applet or other executable content. In HTML 4.0 use OBJECT.');
INSERT tblElement (ElementName, ElementDescription) VALUES ('AREA', 'Specifies the shape of a "hot spot" in a client-side image map .');

-- now create the links
SET @element = (SELECT ElementID FROM tblElement WHERE ElementName = 'A');
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie2);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie3);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie4);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie5);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_nav2);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_nav3);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_nav4);
SET @element = (SELECT ElementID FROM tblElement WHERE ElementName = 'ACRONYM');
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie4);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie5);
SET @element = (SELECT ElementID FROM tblElement WHERE ElementName = 'ADDRESS');
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie2);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie3);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie4);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie5);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_nav2);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_nav3);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_nav4);
SET @element = (SELECT ElementID FROM tblElement WHERE ElementName = 'APPLET');
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie3);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie4);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie5);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_nav2);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_nav3);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_nav4);
SET @element = (SELECT ElementID FROM tblElement WHERE ElementName = 'AREA');
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie3);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie4);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_ie5);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_nav2);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_nav3);
INSERT tblDoesBrowserSupportElement (ElementID, BrowserID) VALUES (@element, @b_nav4);

-- add the user
INSERT tblUser(Username, Password) VALUES ('admin', 'password');