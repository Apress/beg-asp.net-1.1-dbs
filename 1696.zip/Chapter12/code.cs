namespace notashop.band {
    using System;
    using System.Configuration;
    using System.Data;
    using System.Data.SqlClient;
    using System.Web;

    public class DataAccess : IDisposable {
		SqlCommand m_Command;			// holds the command
		SqlConnection m_Connection;		// holds the connection

        public DataAccess()
        {
            // setup the connection object
			m_Connection = new SqlConnection();
			m_Connection.ConnectionString = ConfigurationSettings.AppSettings["Database"];

			// setup the command object
			m_Command = new SqlCommand();
			m_Command.Connection = m_Connection;
        }

		public void Dispose()
		{
            // close the database connection
            CloseConnection();

            // don't want to call the GC
            GC.SuppressFinalize(this);
		}

        private void OpenConnection()
        {
			if (m_Connection.State == ConnectionState.Closed)
			{
				m_Connection.Open();
			}
        }
        private void CloseConnection()
        {
			if (m_Connection.State == ConnectionState.Open)
			{
				m_Connection.Close();
			}
        }

        public SqlDataAdapter ExecuteAdapter(string strCommand)
        {
            return(ExecuteAdapter(strCommand, CommandType.StoredProcedure));
        }
        public SqlDataAdapter ExecuteAdapter(string strCommand, CommandType objType)
        {
			// set the properties correctly
			m_Command.CommandText = strCommand;
			m_Command.CommandType = objType;

			// create the data adapater object
			SqlDataAdapter objAdapter = new SqlDataAdapter(m_Command);

			// return the adapter
			return(objAdapter);
        }

        public int ExecuteNonQuery(string strCommand)
        {
            return(ExecuteNonQuery(strCommand, CommandType.StoredProcedure));
        }
		public int ExecuteNonQuery(string strCommand, CommandType objType)
		{

			// set the properties correctly
			m_Command.CommandText = strCommand;
			m_Command.CommandType = objType;

            // open the database connection
            OpenConnection();

			// execute the query and return the correct result
			int intReturn = m_Command.ExecuteNonQuery();

            // close the connection
            CloseConnection();

			// return the result
			return(intReturn);
		}

        public SqlDataReader ExecuteReader(string strCommand)
        {
            return(ExecuteReader(strCommand, CommandType.StoredProcedure));
        }
		public SqlDataReader ExecuteReader(string strCommand, CommandType objType)
		{
			return(ExecuteReader(strCommand, objType, CommandBehavior.CloseConnection));
		}
		public SqlDataReader ExecuteReader(string strCommand, CommandType objType, CommandBehavior objBehaviour)
		{
			// set the properties correctly
			m_Command.CommandText = strCommand;
			m_Command.CommandType = objType;

            // open the database connection
            OpenConnection();

			// execute the query and return the correct result
			SqlDataReader objReader = m_Command.ExecuteReader(objBehaviour);

			// return the reader
			return(objReader);
		}

        public object ExecuteScalar(string strCommand)
        {
            return(ExecuteScalar(strCommand, CommandType.StoredProcedure));
        }
		public object ExecuteScalar(string strCommand, CommandType objType)
		{

			// set the properties correctly
			m_Command.CommandText = strCommand;
			m_Command.CommandType = objType;

			// open the database connection
			OpenConnection();

            // execute the query and return the correct result
			object objReturn = m_Command.ExecuteScalar();

            // close the connection
            CloseConnection();

            // return the result
            return (objReturn);
		}
    }
}
